class Task {

  String visitId;
  String contactName;
  String userId;
  DateTime visitDate;
  String checkInTime;
  String checkInLat;
  String checkInLong;

  String checkOutTime;
  String checkoutLat;
  String checkoutLong;

  String report;
  String reportdate;

  String status;
  String address;


Task({this.address,this.visitId,this.status,this.contactName,this.userId,this.visitDate,this.checkInTime,this.checkInLat,this.checkInLong,this.checkOutTime,this.checkoutLat,this.checkoutLong,this.report,this.reportdate});


}